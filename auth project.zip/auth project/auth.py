import os
import json
import requests
from bs4 import BeautifulSoup
from cryptography.fernet import Fernet
from getpass import getpass

class AuthManager:
    """Handles authentication, encryption and session management"""
    
    def __init__(self):
        self.credentials_file = "encrypted_credentials_auth.json"
        self.key_file = "secret_auth.key"
        self.key = self._load_or_generate_key()
        self.session = None

    def _load_or_generate_key(self, first_run=False):
        """Load existing key or generate a new one"""
        try:
            with open(self.key_file, "rb") as key_file:
                return key_file.read()
        except FileNotFoundError:
            if not first_run:
                print("Key file not found. Generating new key.")
            return self._generate_key()
        except Exception as e:
            print(f"Key loading failed: {e}")
            return None

    def _generate_key(self):
        """Generate and save a new encryption key"""
        try:
            key = Fernet.generate_key()
            with open(self.key_file, "wb") as key_file:
                key_file.write(key)
            return key
        except Exception as e:
            print(f"Key generation failed: {e}")
            return None

    def encrypt_data(self, data):
        """Encrypt sensitive data"""
        if data is None:
            print("No data to encrypt.")
            return None
        try:
            cipher_suite = Fernet(self.key)
            return cipher_suite.encrypt(data.encode("utf-8"))
        except Exception as e:
            print(f"Encryption failed: {e}")
            return None

    def decrypt_data(self, encrypted_data):
        """Decrypt sensitive data"""
        if encrypted_data is None:
            print("No data to decrypt.")
            return None
        try:
            cipher_suite = Fernet(self.key)
            return cipher_suite.decrypt(encrypted_data).decode("utf-8")
        except Exception as e:
            print(f"Decryption failed: {e}")
            return None

    def save_credentials(self, logintoken, password, username):
        """Save encrypted credentials to file"""
        if None in [logintoken, password, username]:
            print("Cannot save None values as credentials")
            return False

        encrypted_data = {
            "logintoken": self.encrypt_data(str(logintoken)),
            "password": self.encrypt_data(str(password)),
            "username": self.encrypt_data(str(username))
        }

        if None in encrypted_data.values():
            print("Failed to encrypt credentials.")
            return False

        try:
            with open(self.credentials_file, 'w') as f:
                json.dump({k: v.decode() for k, v in encrypted_data.items()}, f)
            return True
        except Exception as e:
            print(f"Failed to save credentials: {e}")
            return False

    def load_credentials(self):
        """Load and decrypt credentials from file"""
        if not os.path.exists(self.credentials_file):
            return None, None, None

        try:
            with open(self.credentials_file, 'r') as f:
                encrypted = json.load(f)
            
            return (
                self.decrypt_data(encrypted['logintoken'].encode() if encrypted['logintoken'] else None),
                self.decrypt_data(encrypted['password'].encode() if encrypted['password'] else None),
                self.decrypt_data(encrypted['username'].encode() if encrypted['username'] else None)
            )
        except Exception as e:
            print(f"Failed to load credentials: {e}")
            return None, None, None

    def delete_credentials(self):
        """Delete the credentials file"""
        try:
            if os.path.exists(self.credentials_file):
                os.remove(self.credentials_file)
                return True
            print("Credentials file not found.")
            return False
        except Exception as e:
            print(f"Failed to delete credentials: {e}")
            return False

    def login(self, username, password):
        """Login to the website and return session"""
        if not username or not password:
            print("Username and password required.")
            return None, None, None, None

        session = requests.Session()
        login_url = "url"
        profile_url = "url"

        try:
            # Get login page and extract token
            response = session.get(login_url, timeout=10)
            response.raise_for_status()

            soup = BeautifulSoup(response.content, 'html.parser')
            logintoken_input = soup.find('input', {'name': 'logintoken'})
            if not logintoken_input:
                print("Login token not found.")
                return None, None, None, None

            logintoken = logintoken_input['value']

            # Attempt login
            login_data = {
                'username': username,
                'password': password,
                'logintoken': logintoken
            }
            response = session.post(login_url, data=login_data, timeout=10)
            
            if response.status_code != 200 or "loginerrors" in response.text:
                print("Invalid credentials or login failed.")
                return None, None, None, None

            # Verify successful login
            response = session.get(profile_url, timeout=10)
            if "You are logged in as" not in response.text:
                print("Login verification failed.")
                return None, None, None, None

            # Extract user name
            soup = BeautifulSoup(response.text, 'html.parser')
            name_element = soup.find('span', class_='usertext mr-1')
            if name_element:
                print(f"\nSuccessfully logged in as {name_element.text.strip()}")
                print("1. Sign out (don't save credentials)")
                print("2. Continue (save credentials)")
                choice = input("Enter your choice (1 or 2): ").strip()
                
                if choice == '1':
                    print("\nSigning out and deleting credentials...")
                    self.delete_credentials()
                    session.close()
                    os._exit(0)
                elif choice == '2':
                    print("\nCredentials will be saved\n")
                else:
                    print("\nInvalid choice. Continuing with saved credentials.\n")

            return session, logintoken, password, username

        except requests.exceptions.RequestException as e:
            print(f"Network error during login: {e}")
            return None, None, None, None

def main():
    """Main application flow"""
    auth = AuthManager()
    
    while True:
        # Load or request credentials
        logintoken, password, username = auth.load_credentials()
        
        if not all([logintoken, password, username]):
            print("\nPlease enter your credentials (type 'exit' to quit)\n")
            username = input("Username: ").strip()
            
            if username.lower() == 'exit':
                print("Exiting program.")
                return
            elif username.lower() == 'reset':
                auth.delete_credentials()
                continue

            password = getpass("Password: ").strip()
            if password.lower() == 'exit':
                print("Exiting program.")
                return

        # Attempt login
        session, new_token, new_pass, new_user = auth.login(username, password)
        if session:
            # Save successful credentials
            if not auth.save_credentials(new_token, new_pass, new_user):
                print("Warning: Failed to save credentials for future use")
            break  # Successful login
        else:
            print("Login failed. Please try again.")

if __name__ == "__main__":
    main()
